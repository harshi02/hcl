package com.bankapp.model.dao;

public enum UserType {
	Admin, Mgr, Clerk;
}


