package com.bankapp.web.controller;

public class Main {

	public static void main(String[] args) {
		
	}

}
