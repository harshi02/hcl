package com.bankapp.model.dao;

public enum AccountStatus {
	
	Activate, Suspended;

}